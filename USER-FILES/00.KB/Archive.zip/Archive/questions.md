# Clarification Questions for Scene-to-Prompt PRD

## Project Metadata

### Q1: Project Name

What should we name this project/tool? 

- Suggested: `scene2prompt` or `scene-prompt-generator`
- This will be used for the main script name and documentation

#### USER RESPONSE: "scene-json->prompt"

### Q2: Version

Should we start with version 1.0.0 or 0.1.0 (following semantic versioning)?

#### USER RESPONSE: 0.1.0

## Technical Architecture

### Q3: Profile System Integration

Should the script support the `03.PROFILES/` folder pattern from the PRD template?

- Example: Different profiles for different prompt styles (cinematic, documentary, artistic)?
- Or should it only use the single `anthropic_config.json` as described?

#### USER RESPONSE: Yes. let have the profiles append a suffix to every prompt value string.

### Q4: Authentication Options

Should we support multiple authentication methods?

- Primary: 1Password CLI (as specified)
- Fallback: Environment variables (ANTHROPIC_API_KEY)
- Config file with encrypted key?



#### USER RESPONSE: Only 1password using the method detailed here. `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/00.KB/1password_cli_auth.md`

### Q5: System Prompt File Ordering

When merging multiple markdown files from `/System Prompt/`:

- Should files be processed alphabetically?
- Should there be a specific order file (e.g., `_order.txt`)?
- Should files be numbered (e.g., `01_style.md`, `02_format.md`)?



#### USER RESPONSE: The text files are marked down and they are already numbered and the numbering should set the order.

## Data Processing

### Q6: Output File Organization

How should output files be organized in `05.OUTPUT/{timestamp}/`?

- One JSON file per input scene file?
- All scenes in a single merged JSON file?
- Both options with a configuration flag?

#### USER RESPONSE: First option

- ### Q7: Batch Processing Limits

Should there be limits on batch processing?

- Maximum scenes per API call?
- Maximum files per processing run?
- Automatic chunking for large batches?

#### USER RESPONSE;  There is always only one scene per API call and usually there are not that many lines so no need for large batches chunking.

### Q8: Failed Validation Handling

When a scene file fails validation:

- Should it remain in `04.INPUT/` for manual review?
- Should it be moved to `06.DONE/` with an error marker?
- Should there be a separate `FAILED/` subfolder?

#### USER RESPONSE: The script should never move folders. Just leave them where they are.



## Error Handling & Recovery

### Q9: Partial Failure Recovery

If processing fails midway through multiple files:

- Should the script support resuming from the last successful file?
- Should it regenerate a checkpoint file?
- Should successfully processed files before the failure be kept?

#### USER RESPONE: No just let it fail.

### Q10: API Error Handling

For different API error types, what's the preferred behavior?

- **401 Unauthorized**: Stop immediately or try alternative auth?
- **429 Rate Limited**: Wait and retry (already specified) - confirm max retries?
- **500 Server Error**: Retry with exponential backoff or skip file?
- **400 Bad Request**: Skip file and continue, or stop for review?



#### USER RESPONSE: 401: just stop and report error. 429: Wait and retry. 500 what every you recommend. 400 stop the script.

## Features & Modes

### Q11: Dry Run Mode

Should there be a `--dry-run` mode that:

- Validates all files without calling the API?
- Estimates token usage and costs?
- Shows what would be sent to the API?



#### USER RESPONSE: All of the above except token cost calc.

### Q12: Processing Modes

Should the script support different modes?

- **Normal**: Process all files in INPUT
- **Single**: Process a specific file
- **Test**: Process first file only
- **Validate**: Check files without processing

#### USER RESPONSE: No

### Q13: Token Usage Tracking

Should the script track and report:

- Total input/output tokens used?
- Estimated cost based on current pricing?
- Per-file token usage in logs?
- Running total across all files?

#### USER RESPONSE: No

## Output & Reporting

### Q14: Summary Report

Should the script generate a summary report showing:

- Total files processed successfully/failed
- Total API calls made
- Total tokens used and estimated cost
- Average processing time per scene
- List of any errors or warnings

####USER RESPONSE: Yes, See /Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/00.KB/PRD Instructions/PRD_Instructions_Template.md

### Q15: Logging Verbosity

What logging levels should be supported?

- DEBUG: Full API requests/responses
- INFO: File processing progress
- WARNING: Validation issues, retries
- ERROR: Failures only



####USER RESPONSE: See /Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/00.KB/PRD Instructions/PRD_Instructions_Template.md

## Configuration

### Q16: Configuration Precedence

If we support multiple configuration sources, what's the precedence?

1. Command-line arguments (highest)
2. Environment variables
3. Profile YAML files
4. Config JSON file (lowest)

#### USER RESPONSE: No multiple config sources. Only the hard codem the yaml profile and json config.

### Q17: Field Removal Configuration

Should the fields to remove (`oref`, `camera_movement`, `shot_timecode`) be:

- Hardcoded as specified?
- Configurable in the config file?
- Configurable per profile?



#### USER RESPONSE: Yeah, it's a good idea to put it in the config file.

## Special Cases

### Q18: Empty Shots Array

How should we handle scenes with no shots?

- Skip with warning?
- Fail validation?
- Send to API anyway?

#### USER RESPONSE: Stop and exit. Write problem in log.

### Q19: Duplicate Scene Numbers

If multiple files have the same scene_number:

- Process all (may have duplicates in output)?
- Skip duplicates with warning?
- Fail with error?

#### USER RESPONSE: Stop, fail and report.

### Q20: Input Folder Structure

The doc mentions "a folder" in `04.INPUT/`:

- Should the script process all JSON files recursively?
- Should it maintain folder structure in output?
- Should it only process files in the root of the folder?

## #### USER RESPONSE:Yes, recurrsive, No need to maintain structure. Only folder in the root of 04.INPUT/



## Additional Considerations

### Q21: Performance Optimization

Should the script include:

- Parallel processing option for multiple files?
- Connection pooling for API requests?
- Caching of system prompts between files?

### #### USER RESPONSE: Lets see what the anthropic says about parallel calls. Yes! system prompts should def be cached on run. I will later provide documentation that will detail how this is handles by Anthropic SDK.

### Q22: Testing Requirements

What level of testing is expected?

- Unit tests for validation and transformation functions?
- Integration tests with mock API?
- End-to-end tests with real API (requires key)?
  

### #### USER RESPONSE: Basic testing. Nothing too fancy.

### Q23: Dependencies

Are there any restrictions on dependencies?

- Prefer standard library where possible?
- Specific versions of anthropic SDK?
- Any libraries to avoid?

### #### USER RESPONSE: Do what you think is best.

### Q24: Future Extensions

Should the design accommodate future features like:

- Support for other AI providers (OpenAI, etc.)?
- Batch processing via Anthropic's batch API?
- Web UI or API server mode?



## #### USER RESPONSE: No thank you

## Implementation Priority

### Q25: MVP vs Full Feature Set

For initial implementation, which features are:

- **Must Have**: Core functionality only?
- **Nice to Have**: Can be added later?
- **Future**: Out of scope for v1?

#### USER RESPONSE: 100% MVP



---

## Quick Decision Summary Needed

For rapid development, please confirm these assumptions or provide corrections:

1. **Project name**: `scene2prompt`
2. **Single config file**: Use only `anthropic_config.json` (no profiles for v1)
3. **Auth**: 1Password CLI primary, env variable fallback
4. **Output**: One file per input scene file
5. **Validation failures**: Skip and continue, log errors
6. **System prompts**: Process alphabetically
7. **No dry-run mode** for v1
8. **Basic logging**: INFO level by default
9. **Hardcoded field removal**: As specified in document
10. **Sequential processing**: No parallel processing in v1