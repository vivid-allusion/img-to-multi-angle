# Refactoring Report - Python File Size Analysis

Based on the Python File Size Management Guidelines (250 soft limit, 400 hard limit)

## Current File Status

| File | Lines | Status | Action Required |
|------|-------|--------|-----------------|
| **main.py** | 374 | ⚠️ Over soft limit | Should refactor |
| **cost_tracker.py** | 305 | ⚠️ Over soft limit | Should refactor |
| config.py | 217 | ✅ Within limits | OK |
| api_client.py | 115 | ✅ Within limits | OK |
| validator.py | 59 | ✅ Within limits | OK |
| auth.py | 47 | ✅ Within limits | OK |

## Priority 1: main.py (374 lines)

### Current Structure
- 6 functions with mixed responsibilities
- Combines orchestration, file discovery, error handling, and reporting

### Recommended Split
Split into 3 focused modules:

1. **main.py** (~100 lines)
   - Keep only `main()` function
   - Command-line argument parsing
   - High-level orchestration

2. **scene_processor.py** (~150 lines)
   - `process_all_scenes()`
   - `discover_scene_files()`
   - Core processing logic

3. **reporting.py** (~120 lines)
   - `create_failure_report()`
   - `generate_summary()`
   - `setup_logging()`
   - All reporting and logging functionality

### Benefits
- Clear separation of concerns
- Easier testing of individual components
- Better maintainability

## Priority 2: cost_tracker.py (305 lines)

### Current Structure
- 1 dataclass (UsageStats)
- 6 functions for cost calculation and reporting
- Mixed responsibilities: data tracking, cost calculation, report generation

### Recommended Split
Split into 2 modules:

1. **cost_calculator.py** (~120 lines)
   - `UsageStats` dataclass
   - `calculate_cost()`
   - `_get_input_rate()`
   - `_calculate_cache_cost()`
   - Core cost calculation logic

2. **cost_reporter.py** (~180 lines)
   - `generate_cost_report()`
   - `_estimate_model_cost()`
   - `_get_caching_advice()`
   - Report generation and formatting

### Benefits
- Separates data/calculation from presentation
- Allows reuse of cost calculation without report generation
- Cleaner testing boundaries

## Implementation Plan

### Phase 1: Refactor main.py
```python
# New file structure:
src/
├── main.py              # CLI entry point only
├── scene_processor.py   # Core processing logic
├── reporting.py         # All reporting functions
├── config.py           # (unchanged)
├── api_client.py       # (unchanged)
├── validator.py        # (unchanged)
└── auth.py            # (unchanged)
```

### Phase 2: Refactor cost_tracker.py
```python
# New file structure:
src/
├── cost_calculator.py   # Cost calculation logic
├── cost_reporter.py     # Cost report generation
└── ... (other files)
```

## Code Quality Improvements

### Additional Refactoring Opportunities

1. **Extract Constants**
   - Move magic numbers to configuration
   - Define report templates as constants

2. **Improve Type Hints**
   - Add more specific return type hints
   - Use TypedDict for complex dictionaries

3. **Error Handling**
   - Consolidate error handling patterns
   - Create custom exception classes

## Migration Path

### Step 1: Create New Modules
1. Create empty new module files
2. Move functions maintaining imports
3. Update internal imports

### Step 2: Update Imports
1. Update all files importing from split modules
2. Maintain backward compatibility temporarily
3. Test thoroughly

### Step 3: Clean Up
1. Remove any duplicate code
2. Optimize imports
3. Run tests to ensure nothing broke

## Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| Breaking imports | High | Create compatibility imports initially |
| Lost functionality | Medium | Comprehensive testing before/after |
| Merge conflicts | Low | Complete refactor in single PR |

## Estimated Effort

- **main.py refactor**: 1 hour
- **cost_tracker.py refactor**: 45 minutes
- **Testing & validation**: 30 minutes
- **Total**: ~2.25 hours

## Summary

Both `main.py` (374 lines) and `cost_tracker.py` (305 lines) exceed the 250-line soft limit and should be refactored. The proposed splits follow the guidelines:
- Separate by logical boundaries
- One primary responsibility per file
- Clear, descriptive filenames
- Maintains existing APIs

This refactoring will improve:
- **Readability**: Smaller, focused files
- **Maintainability**: Clear separation of concerns
- **Testability**: Isolated components
- **Future development**: Easier to extend individual modules