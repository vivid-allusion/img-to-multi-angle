# System Prompt Improvement Report

**Date:** August 16, 2025  
**Reviewer:** Claude Code  
**Project:** scene-json->prompt v0.1.0  

## Executive Summary

After reviewing the entire codebase, PRD, original script idea, and current system prompts, I've identified several areas where the system prompts could be enhanced to better align with your project's intentions. The current prompts are well-structured but miss some critical technical details and specific requirements from your original vision.

---

## 1. Understanding Your Core Intention

Based on my analysis, your project's core purpose is:

1. **Transform technical screenplay data into AI-ready prompts** - Converting industry-standard shot descriptions into Midjourney-optimized visual descriptions
2. **Maintain cinematic authenticity** - Respecting the original screenplay's vision while translating technical jargon
3. **Preserve scene continuity** - Ensuring multiple shots within a scene maintain visual coherence
4. **Optimize for Midjourney v6** - Creating prompts specifically tuned for this platform's capabilities

**USER RESPONSE:**  These are good, but note that the latest version of Midjourney is V7.

---

## 2. Current System Prompt Strengths

Your existing prompts excel in:

- Clear role definition as a "cinematic prompt engineer"
- Emphasis on period accuracy and atmospheric preservation  
- Good shot size guidelines (though incomplete)
- Proper tool function response structure
- Quality checklist for validation

**USER RESPONSE:** Great

---

## 3. Critical Gaps Identified

### 3.1 Missing Shot Types

Your codebase handles shot types not covered in the prompts:

- **Crane Shot** - Elevated, sweeping perspectives
- **Long Shot (LS)** - Similar to Wide Shot but distinct
- **Low Medium Shot** - Specific angle variation
- Various angle modifiers (High Angle, Low Angle, Dutch Angle)

### 

**USER RESPONSE:** Please tell me where you find these. 

**CLAUDE RESPONSE:**

I found these shot types in your original `script_idea.md` file (lines 119, 141, 184, etc.). For example:

- Line 119: `"shot_size": "Crane Shot"`
- Line 184: `"shot_size": "Low Medium Shot"` 
- Line 547: `"shot_size": "Long Shot"`

However, upon reviewing the actual codebase, these are just values in the JSON data, not something the code specifically handles differently. The system prompt should be prepared to interpret whatever shot_size values appear in the data.

**USER RESPONSE2:** Exactly, as long as they are something mentioned in the key value and not its own field, it doesn't really matter. 

### 3.2 Unaddressed JSON Fields

The system doesn't guide the AI on handling:

- `specific_area` field (e.g., "Center aisle", "Main room")
- Nested `location` structure with `type` and `location_name`
- `comment` field containing director's intent
- `diurnal` field for time of day
- `season` and `weather` context fields

**USER RESPONSE:** What do you mean by "the system"? The system prompt? or the system as in the codebase? `specific_area` is a child of location like `Ruben's apartment` and the `specific area` is `kithen`.  All of these other fields that you mentioned must be handed over to the payload.But this isn't really system prompt. This is more what the script reads and passes through the JSON array that it sends as a user message.

**CLAUDE RESPONSE:**

You're absolutely right. I meant "the system prompt" doesn't guide the AI. These fields ARE passed in the JSON payload (after removing oref, camera_movement, shot_timecode). The system prompt needs to tell the AI how to interpret and use these fields when they appear in the JSON. 

Actually, I see now that `specific_area` is at the shot level (not nested under location). The system prompt should instruct the AI on how to incorporate these contextual fields into the visual descriptions when generating prompts.

**USER RESPONSE2:**Yes

### 3.3 Conciseness vs. Detail Balance

- Your examples show 50-80 word prompts
- Current prompts generate 80-120 words
- Midjourney performs better with concise, focused descriptions

**USER RESPONSE:**Yes, you are correct. Include that in the system prompt that the image prompt should be no more than 50 to 80 words tops

### 3.4 Scene Context Inheritance

The prompts don't emphasize enough that:

- ALL shots inherit scene-level context
- Scene descriptors (period, location, lighting) apply to every shot
- Continuity must be maintained across shots in the same scene

**USER RESPONSE:**  Okay, this is absolutely critical. Make sure that it does that.

---

## 4. Specific Improvement Recommendations

### 4.1 Enhanced Role Definition (01.Role Definition.md)

```markdown
## Role Definition

You are a cinematic prompt engineer specializing in transforming structured screenplay JSON data into optimized Midjourney v7 image prompts. Your expertise spans:

1. **Technical Translation**: Converting film industry terminology (shot sizes, camera angles, movements) into visual descriptions
2. **Scene Context Integration**: Understanding how scene-level metadata (period, location, lighting, weather) influences every shot
3. **Visual Continuity**: Maintaining consistent visual elements across multiple shots within the same scene
4. **Midjourney Optimization**: Crafting prompts that leverage Midjourney v7's strengths while avoiding its limitations

You process array-wrapped JSON scenes with nested shot data, respecting the hierarchical relationship between scene context and individual shots.
```

**USER RESPONSE:** Good 

### 4.2 Refined Task Description (02.Task Description.md)

```markdown
## Task Description

Process JSON scene data to generate Midjourney-optimized prompts following this hierarchy:

1. **Scene Level Analysis**:
   - Extract global context: period, location (type + location_name), season, weather
   - Note lighting conditions: diurnal (time of day) and light_source
   - Understand director's intent from comment field

2. **Shot Level Processing**:
   - Identify shot_size and translate to compositional focus
   - Incorporate specific_area to enhance spatial context
   - Transform description into visual elements
   - Apply scene-level context to every shot

3. **Prompt Generation Rules**:
   - Keep prompts concise: 50-80 words optimal
   - Start with period/location when historically relevant
   - Focus on visual elements, not narrative
   - Maintain continuity across shots in same scene
   - Avoid repetition of scene context in every shot

Output via the generate_prompts tool function with proper JSON structure.
```

**USER RESPONSE:**  This is good apart from this one.  "Avoid repetition of scene context in every shot" As Midjourney doesn't have any context awareness across image prompts, so each image prompt must repeat the scene context.

### 4.3 Complete Shot Size Guidelines (03.Constraints & Focus.md)

Add these missing shot types:

```markdown
### Complete Shot Size Translation

**Standard Shots:**
- ECU (Extreme Close-Up): Minute details, single features
- CU (Close-Up): Face/object filling frame
- MCU (Medium Close-Up): Chest up
- MS (Medium Shot): Waist up
- MWS (Medium Wide Shot): Full figure
- WS/LS (Wide/Long Shot): Full scene context
- EWS (Extreme Wide Shot): Epic scale

**Special Angles:**
- Crane Shot: Elevated, sweeping view
- Low Angle: Camera below subject
- High Angle: Camera above subject
- Dutch Angle: Tilted frame
- POV Shot: First-person perspective
- OTS (Over-the-Shoulder): Behind character

**Camera Movements (context only):**
- Note but don't describe: Dolly, Pan, Tilt, Zoom
- These affect framing, not content
```

**USER RESPONSE:** The special angles are included in the descriptions and they are not really independent fields. So the system prompt doesn't really need to handle them. Also, camera movements are not passed to the payload as these are image prompts and not video prompts that contain or need prompting for movement.

### 4.4 Context-Aware Examples (04.Few Shots.md)

Provide examples showing scene context inheritance

```
## Example: Multi-Shot Scene

**Input (cleaned):**

```json
{
  "scene_number": 2,
  "comment": "Religious conversion ceremony in Lutheran Sweden",
  "period": "Late 1700s",
  "location": {
    "type": "Interior",
    "location_name": "Medieval church"
  },
  "diurnal": "Day",
  "light_source": "Sunlight through stained glass",
  "shots": [
    {
      "shot_number": 2,
      "shot_size": "Long Shot",
      "specific_area": "Center aisle",
      "description": "Liturgical procession advances..."
    },
    {
      "shot_number": 3,
      "shot_size": "ECU",
      "specific_area": "Pews",
      "description": "Teenage girl praying..."
    }
  ]
}
```

**Generated Prompts:**

```json
{
  "scene_number": 2,
  "shots": [
    {
      "shot_number": 2,
      "prompt": "Late 1700s medieval church interior, long shot down center aisle. Liturgical procession with priest in vestments, congregation in period dress. Sunlight through stained glass creating colored patterns on stone floor."
    },
    {
      "shot_number": 3,
      "prompt": "Extreme close-up teenage girl's face in prayer, hands clasped, eyes closed. Soft colored light from stained glass window illuminating features. Period-appropriate 18th century dress and hairstyle."
    }
  ]
}
```

**USER RESPONSE:**  Let's do this.

### 4.5 Thinking Framework (05.Think.md)

```markdown
## Think

Before generating each prompt, systematically consider:

1. **Scene Context Extraction**:
   - What period/era influences visual style?
   - What location details affect composition?
   - How do lighting/weather create atmosphere?

2. **Shot-Specific Analysis**:
   - What's the primary subject in frame?
   - How does shot_size determine composition?
   - What specific_area details enhance spatial understanding?

3. **Continuity Check**:
   - Is this part of a multi-shot scene?
   - What visual elements must remain consistent?
   - How to avoid repetition while maintaining coherence?

4. **Midjourney Optimization**:
   - Is the prompt concise (50-80 words)?
   - Are visual descriptors concrete, not abstract?
   - Does word order prioritize important elements?
```

**USER RESPONSE:** Great

### 4.6 Enhanced Output Guidelines (06.Output Format.md)

```markdown
## Output Format

### Critical Requirements:
- Never exceed 80 words per prompt
- Never include camera movement descriptions
- Never add Midjourney parameters (handled by profile)
- Always preserve shot and scene numbers exactly

### Prompt Structure Priority:
1. Period/era (if historically significant)
2. Shot size translation
3. Primary subject and action
4. Location/spatial context
5. Lighting and atmosphere
6. Supporting visual elements

### Field Handling:
- `comment`: Use for understanding intent, don't include literally
- `specific_area`: Integrate naturally into spatial description
- `location.type` + `location.location_name`: Combine smoothly
- `diurnal`: Translate to time-of-day lighting
- `light_source`: Describe visual effect, not technical setup
```

**USER RESPONSE:** This is great. But what do you mean here: "`light_source`: Describe visual effect, not technical setup"

**CLAUDE RESPONSE:**

I mean when the JSON has `"light_source": "Dappled Sunlight from a skylight"`, the prompt should describe the visual result ("dappled sunlight creating warm patches on the floor") rather than the technical setup ("skylight above"). Focus on how the light looks in the image, not the equipment or architecture creating it. 

Another example: `"light_source": "Sunlight through stained glass"` → describe "colored light patterns on stone floor" not "stained glass windows".

**USER RESPONSE2:**Exactly, you got it!!!!

---

## 5. Additional System Prompt Files to Consider

### 5.1 Create "07.Field_Mapping.md"

```markdown
## JSON Field to Visual Element Mapping

| JSON Field | Visual Translation |
|------------|-------------------|
| period | Era-specific architecture, clothing, technology |
| location.type | Interior/Exterior lighting and spatial feel |
| location.location_name | Specific architectural/environmental details |
| season | Foliage, weather, clothing weight |
| weather | Sky conditions, wet surfaces, atmospheric effects |
| diurnal | Time-of-day lighting quality and direction |
| light_source | Specific lighting effects and shadows |
| specific_area | Precise spatial positioning within location |
| shot_size | Camera distance and compositional framing |
| description | Core visual content to be enhanced |
```

**USER RESPONSE: ** Yes great idea. This is absolutely critical.

### 5.2 Create "08.Common_Pitfalls.md"

```markdown
## Common Pitfalls to Avoid

1. **Over-describing**: Midjourney works best with focused descriptions
2. **Technical jargon**: Avoid filmmaking terms in final prompts
3. **Emotional interpretation**: Stick to visual facts
4. **Modern anachronisms**: Respect historical periods
5. **Repetitive scene context**: Don't repeat location in every shot
6. **Abstract concepts**: Use concrete visual descriptors
7. **Multiple focal points**: Maintain clear visual hierarchy
```

**USER RESPONSE: Yes lets do it**

---

## 6. Configuration Alignment Suggestions

### 6.1 Temperature Setting

Current: 0.7 (creative)  
Recommended: 0.3 (factual)  
Reason: Lower temperature ensures consistency and adherence to source material

**USER RESPONSE: Yes lets do it**

### 6.2 Max Tokens

Current: 4096  
Recommended: 1600  
Reason: Prompts should be 50-80 words; 1600 tokens is sufficient for multiple shots

**USER RESPONSE:** Isn't max tokens just a cap and not a directive? The script instructs or the system prompt instructs Anthropic model to stick to 80 words per prompt We won't save tokens if the max token configuration goes beyond that Or are you implementing this as a godrail for prompts that are too long?

**CLAUDE RESPONSE:**

You're absolutely correct! Max tokens is just a cap, not a directive. The system prompt already instructs the model to keep prompts at 50-80 words. The max_tokens setting is only a safety guardrail to prevent runaway responses. 

Since you might have scenes with 10+ shots, and each prompt is ~80 words, 4096 tokens is actually reasonable. My recommendation of 1600 was too restrictive. Keep it at 4096 - it won't affect token usage, the model will still generate concise prompts based on the system prompt instructions.

**USER RESPONSE2:**Sounds good

### 6.3 Tool Description Update

```yaml
tool:
  name: generate_prompts
  description: Transform cinematic JSON scene data into concise Midjourney v7 prompts
```

**USER RESPONSE:** I dont really understand what this is? Is this from the config file?

**CLAUDE RESPONSE:**

Yes, this is from your `anthropic_config.yaml` file. The tool description tells the Anthropic API what the function does. Currently it says "Generate AI image prompts for a scene with shots". I'm suggesting updating it to be more specific: "Transform cinematic JSON scene data into concise Midjourney v7 prompts" to better reflect the tool's purpose. It's a minor update that helps with API logging and clarity.

**USER RESPONSE2:** This is another example of legacy garbage left in the config file. It was done at a very early stage and it is not authoritative on how the script should work. The config file is always subject to what is the actual plan in more recent documents.

---

## 7. Testing Recommendations

Create test cases for:

1. Single-shot scenes
2. Multi-shot scenes requiring continuity
3. Complex nested location structures
4. Various shot sizes including special angles
5. Historical period accuracy
6. Weather and lighting integration

**USER RESPONSE:** Good

---

## 8. Summary of Key Improvements

1. **Add missing shot types** (Crane, Long Shot, angle variations)
2. **Emphasize scene context inheritance** for multi-shot continuity
3. **Reduce prompt length** to 50-80 words for optimal Midjourney performance
4. **Add field mapping guide** for consistent JSON interpretation
5. **Include pitfall warnings** to prevent common errors
6. **Adjust temperature** to 0.3 for factual consistency
7. **Create hierarchical processing** (scene → shots)

**USER RESPONSE:** See My responses above.

---

## 9. Implementation Priority

### Immediate (High Impact):

1. Update 03.Constraints & Focus.md with complete shot sizes
2. Adjust temperature in anthropic_config.yaml to 0.3
3. Update 02.Task Description.md with hierarchical processing

### Short-term (Medium Impact):

4. Revise 04.Few Shots.md with multi-shot examples
5. Create 07.Field_Mapping.md
6. Update 06.Output Format.md with word limits

### Long-term (Enhancement):

7. Create 08.Common_Pitfalls.md
8. Add test scene files for validation
9. Document edge cases and solutions

**USER RESPONSE: No Comment.**

---

## Conclusion

Your system prompts are fundamentally sound but need refinement to fully capture your vision of a minimalist, efficient scene-to-prompt converter. The key improvements focus on:

1. **Technical completeness** - Supporting all shot types and fields
2. **Contextual awareness** - Understanding scene-shot hierarchy
3. **Output optimization** - Concise prompts for Midjourney v7
4. **Continuity preservation** - Maintaining visual coherence

These improvements will ensure the system generates prompts that are both technically accurate to the screenplay and optimized for Midjourney's image generation capabilities.

The suggested changes maintain your minimalist philosophy while adding necessary precision for consistent, high-quality results.

**USER RESPONSE:** No comment.