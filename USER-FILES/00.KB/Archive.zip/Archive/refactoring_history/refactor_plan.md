# Python File Size Refactoring Plan

## 🎯 Objective
Refactor all Python files to comply with the 400-line hard limit and 250-line soft limit while maintaining functionality, readability, and testability.

## 📊 Current State Analysis

### Critical Violations (Files > 400 lines)
1. **src/api/client.py** - 671 lines (1 class, 15+ methods)
2. **src/utils/error_handler.py** - 506 lines (4 classes)
3. **src/api/rate_limiter.py** - 451 lines (4 classes)
4. **src/utils/tool_handler.py** - 440 lines (3 classes)

### Import Dependencies
- `src/main.py` imports from `api` and `utils` packages
- Test files directly import from these modules
- Public API exposed through `__init__.py` files

## 🔨 Refactoring Strategy

### Phase 1: Critical Files (Week 1)

#### Day 1-2: src/api/client.py (671 → ~200 lines each)
**Split into 4 modules:**

```python
# src/api/client.py (200 lines) - Core client only
class AnthropicClient:
    def __init__()
    def process_scene()
    def process_scenes()
    
# src/api/request_handler.py (150 lines)
class RequestHandler:
    def build_request()
    def validate_request()
    def prepare_headers()
    
# src/api/response_processor.py (170 lines)
class ResponseProcessor:
    def process_response()
    def extract_content()
    def handle_tool_use()
    
# src/api/statistics_tracker.py (150 lines)
class StatisticsTracker:
    def track_request()
    def get_statistics()
    def reset_statistics()
```

**Migration Steps:**
1. Create new files with stubbed classes
2. Move methods one by one, testing after each move
3. Update imports in client.py to use new modules
4. Update __init__.py exports
5. Run full test suite
6. Update all importing files

#### Day 3: src/utils/error_handler.py (506 → ~170 lines each)
**Split into 3 modules:**

```python
# src/utils/error_types.py (100 lines)
class ErrorCategory(Enum)
class ErrorContext
class RetryConfig

# src/utils/error_handler.py (200 lines)
class AnthropicErrorHandler:
    # Core error handling logic only

# src/utils/error_strategies.py (200 lines)
class RetryStrategy:
    def calculate_delay()
    def should_retry()
class ErrorStatistics:
    def track_error()
    def get_statistics()
```

#### Day 4: src/api/rate_limiter.py (451 → ~150 lines each)
**Split into 3 modules:**

```python
# src/api/rate_limit_types.py (100 lines)
class ThrottleReason(Enum)
class RateLimitMetrics
class RateLimitState

# src/api/rate_limiter.py (200 lines)
class RateLimiter:
    # Core limiting logic only

# src/api/rate_limit_tracker.py (150 lines)
class RateLimitTracker:
    def update_from_headers()
    def get_performance_summary()
```

#### Day 5: src/utils/tool_handler.py (440 → ~150 lines each)
**Split into 3 modules:**

```python
# src/utils/tool_definitions.py (100 lines)
class ToolDefinitions:
    @staticmethod
    def scene_to_prompt_tool()
    @staticmethod
    def get_available_tools()

# src/utils/tool_handler.py (200 lines)
class ToolHandler:
    # Core tool handling logic

# src/utils/tool_processor.py (140 lines)
class ToolResponseProcessor:
    # Response processing logic
```

### Phase 2: Soft Limit Violations (Week 2)

#### Priority Order (by size):
1. src/config.py (334 lines) → Split configuration types from loader
2. tests/test_config_loading.py (329 lines) → Split into multiple test files
3. tests/mock_api_client.py (289 lines) → Separate mock implementations
4. tests/test_file_validation.py (285 lines) → Group by validation type
5. examples/error_handling_demo.py (283 lines) → Split into multiple examples

### Phase 3: Prevention & Monitoring (Week 3)

#### Automated Enforcement
```yaml
# .github/workflows/file-size-check.yml
name: File Size Check
on: [push, pull_request]
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Check Python file sizes
        run: |
          for file in $(find . -name "*.py" -type f); do
            lines=$(wc -l < "$file")
            if [ $lines -gt 400 ]; then
              echo "ERROR: $file has $lines lines (exceeds 400 limit)"
              exit 1
            elif [ $lines -gt 250 ]; then
              echo "WARNING: $file has $lines lines (exceeds 250 soft limit)"
            fi
          done
```

## 🧪 Testing Strategy

### For Each Refactored File:
1. **Before Split:**
   - Run existing tests, record coverage
   - Create integration test capturing current behavior
   - Document all public APIs

2. **During Split:**
   - Keep old file functional (proxy to new modules initially)
   - Add unit tests for each new module
   - Verify no circular imports

3. **After Split:**
   - Run full test suite
   - Compare coverage (must be ≥ original)
   - Performance benchmark (ensure no regression)

### Test Refactoring Example:
```python
# Before: tests/test_client.py (one large file)
# After:
tests/
  test_client_core.py      # Core client tests
  test_request_handler.py  # Request handling tests
  test_response_processor.py # Response processing tests
  test_statistics_tracker.py # Statistics tests
```

## 📝 Implementation Checklist

### Pre-Refactoring:
- [ ] Create feature branch: `feature/file-size-compliance`
- [ ] Set up file size monitoring script
- [ ] Document current API surface
- [ ] Ensure 100% test coverage on files to be refactored

### Per-File Refactoring:
- [ ] Create new module files
- [ ] Move enums/types first (least dependencies)
- [ ] Move utility functions second
- [ ] Move classes last (most dependencies)
- [ ] Update __init__.py exports
- [ ] Fix all imports in other files
- [ ] Run tests after each step
- [ ] Update documentation

### Post-Refactoring:
- [ ] Run full test suite
- [ ] Check for circular imports
- [ ] Verify no performance regression
- [ ] Update API documentation
- [ ] Set up CI/CD checks

## 🚨 Risk Mitigation

### Potential Issues & Solutions:

1. **Circular Imports**
   - Solution: Use TYPE_CHECKING imports and forward references
   - Tool: `python -m pyflakes` to detect

2. **Breaking API Changes**
   - Solution: Keep original files as facades initially
   - Deprecate gradually over 2 releases

3. **Test Coverage Drop**
   - Solution: Write tests BEFORE refactoring
   - Requirement: Coverage must not decrease

4. **Performance Regression**
   - Solution: Benchmark before/after each change
   - Tool: `python -m cProfile` for hotspots

## 📅 Timeline

### Week 1: Critical Files
- Mon-Tue: client.py refactoring
- Wed: error_handler.py refactoring  
- Thu: rate_limiter.py refactoring
- Fri: tool_handler.py refactoring

### Week 2: Soft Violations
- Mon-Tue: config.py and test files
- Wed-Thu: Remaining production code
- Fri: Documentation updates

### Week 3: Automation
- Mon-Tue: CI/CD pipeline setup
- Wed: Pre-commit hooks
- Thu: Team training
- Fri: Monitoring dashboard

## 🔧 Tooling

### Required Tools:
```bash
# Install development tools
pip install pyflakes  # Detect circular imports
pip install coverage  # Test coverage
pip install black     # Code formatting
pip install ruff      # Linting
pip install pre-commit # Git hooks
```

### Pre-commit Configuration:
```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: check-file-size
        name: Check Python file size
        entry: scripts/check_file_size.py
        language: python
        files: \.py$
```

### Monitoring Script:
```python
# scripts/check_file_size.py
#!/usr/bin/env python3
import sys
from pathlib import Path

SOFT_LIMIT = 250
HARD_LIMIT = 400

def check_files():
    violations = []
    warnings = []
    
    for py_file in Path('.').rglob('*.py'):
        if '.git' in str(py_file):
            continue
            
        lines = py_file.read_text().count('\n')
        
        if lines > HARD_LIMIT:
            violations.append(f"{py_file}: {lines} lines (HARD LIMIT)")
        elif lines > SOFT_LIMIT:
            warnings.append(f"{py_file}: {lines} lines (soft limit)")
    
    if violations:
        print("❌ VIOLATIONS:")
        for v in violations:
            print(f"  {v}")
        sys.exit(1)
    
    if warnings:
        print("⚠️  Warnings:")
        for w in warnings:
            print(f"  {w}")
    
    print("✅ All files within limits")

if __name__ == "__main__":
    check_files()
```

## 🎯 Success Criteria

### Must Have:
- ✅ No files > 400 lines
- ✅ All tests passing
- ✅ No performance regression
- ✅ CI/CD enforcement active

### Should Have:
- ✅ No files > 250 lines (except approved exceptions)
- ✅ Improved code organization
- ✅ Better test structure
- ✅ Enhanced documentation

### Nice to Have:
- ✅ Reduced coupling between modules
- ✅ Easier onboarding for new developers
- ✅ Faster test execution
- ✅ Better code reusability

## 💡 Alternative Approaches Considered

### Option A: Gradual Refactoring
- Pros: Less risk, can be done alongside features
- Cons: Takes longer, inconsistent codebase
- **Decision: Rejected - need immediate compliance**

### Option B: Complete Rewrite
- Pros: Clean architecture, modern patterns
- Cons: High risk, time consuming
- **Decision: Rejected - too disruptive**

### Option C: Targeted Splitting (Selected)
- Pros: Balanced risk, maintains stability
- Cons: Requires careful planning
- **Decision: Selected - best balance**

## 📚 References

- [Python File Size Guidelines](../00.KB/claude_code_memo.md)
- [PEP 8 - Style Guide](https://pep8.org/)
- [Clean Code principles](https://clean-code-python.readthedocs.io/)
- [Refactoring by Martin Fowler](https://refactoring.com/)

## 🔄 Review & Approval

### Review Checklist:
- [ ] Architecture review by tech lead
- [ ] Security review (no exposed internals)
- [ ] Performance benchmarks approved
- [ ] Documentation updated
- [ ] Team trained on new structure

### Sign-offs Required:
- [ ] Tech Lead
- [ ] QA Lead
- [ ] Product Owner (for timeline)

---

*This plan prioritizes maintaining stability while achieving compliance. The phased approach minimizes risk and allows for course correction if issues arise.*