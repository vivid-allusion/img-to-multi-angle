# Anthropic API Integration Recommendations
## For Scene-JSON-to-Prompt Conversion Script v0.1.0

Based on comprehensive review of Anthropic API documentation and analysis of typical scene file sizes (~1.6KB per file), here are the technical recommendations for implementing the Python script.

## Critical Features (Must Implement)

### 1. Stop Reason Handling
Every API response includes a `stop_reason` that must be checked:

```python
# Expected stop reasons for this use case:
- "end_turn"    # Normal completion (most common)
- "tool_use"    # Tool response ready (expected with tool-based approach)
- "refusal"     # Safety refusal (log and skip scene)
- "max_tokens"  # Response truncated (unlikely with short prompts)
```

**Implementation requirement**: Check `stop_reason` on every response and handle accordingly.

### 2. Error Handling with Retry Logic
Implement specific handling for common API errors:

```python
# Essential error types to handle:
- 429 (RateLimitError)      # Use retry-after header or exponential backoff
- 500 (APIError)            # Retry with exponential backoff
- 401 (AuthenticationError) # Fatal - check API key
- 400 (InvalidRequestError) # Log problematic scene and skip
```

**Implementation requirement**: Use try-except blocks with specific error type handling.

### 3. Rate Limiting Strategy
Given small file sizes, implement simple but effective rate limiting:

- **Fixed delay**: 200ms between requests (as specified in PRD)
- **Exponential backoff**: On 429 errors, wait and retry
- **Token bucket awareness**: Monitor but don't over-engineer

```python
# Basic rate limiting approach
time.sleep(0.2)  # 200ms delay between requests
```

### 4. Tool-Based API Interaction
As specified in PRD, use the tool-based approach:

```python
request_params = {
    "model": "claude-opus-4-1-20250805",
    "max_tokens": 4096,
    "temperature": 0.3,
    "tools": [{
        "name": "scene_to_prompt",
        "description": "Convert scene JSON to Midjourney prompts",
        "input_schema": {...}
    }],
    "tool_choice": {"type": "tool", "name": "scene_to_prompt"}
}
```

### 5. Response Header Monitoring
Monitor key headers for intelligent rate limiting:

```python
# Key headers to track:
- "retry-after"                              # Seconds to wait before retry
- "anthropic-ratelimit-requests-remaining"  # Requests left
- "anthropic-ratelimit-tokens-remaining"    # Tokens left
- "request-id"                              # For debugging/support
```

## Important Features (Should Implement)

### 1. Request ID Tracking
Store the `request-id` header for debugging:
- Essential for support tickets
- Helps track problematic scenes
- Useful for audit logging

### 2. Usage Monitoring
Track token consumption for cost management:
```python
usage = response.usage
input_tokens = usage.input_tokens
output_tokens = usage.output_tokens
```

### 3. Graceful Degradation
Implement fallback behavior:
- If tool_use fails, try direct completion
- If refusal occurs, log and continue with next scene
- If max_tokens hit, log warning but accept partial response

## Optional Features (Nice to Have)

### 1. Message Batches API ❌
**Not recommended** for this use case:
- Scene files are small (~1.6KB)
- Adds unnecessary complexity
- Better for bulk processing of 1000+ items

### 2. Prompt Caching ❌
**Not recommended** for this use case:
- Small context windows (~500 tokens)
- Caching benefits minimal
- Adds implementation complexity

### 3. Streaming Responses ❌
**Not recommended** for this use case:
- Prompts are short (50-80 words)
- No benefit for small responses
- Complicates error handling

### 4. Long Context Handling ❌
**Not needed**:
- Scene files are small
- Standard rate limits sufficient
- No 200K+ token requests expected

## Recommended Implementation Pattern

```python
import time
from anthropic import Anthropic, RateLimitError, APIError

class SceneToPromptConverter:
    def __init__(self, api_key):
        self.client = Anthropic(api_key=api_key)
        self.delay = 0.2  # 200ms between requests
        
    def process_scene(self, scene_data, retry_count=0):
        """Process a single scene with robust error handling."""
        
        # Rate limiting
        time.sleep(self.delay)
        
        try:
            response = self.client.messages.create(
                model="claude-opus-4-1-20250805",
                max_tokens=4096,
                temperature=0.3,
                tools=[self.scene_to_prompt_tool],
                tool_choice={"type": "tool", "name": "scene_to_prompt"},
                messages=[{
                    "role": "user",
                    "content": json.dumps(scene_data)
                }]
            )
            
            # Handle stop reasons
            if response.stop_reason == "tool_use":
                return self.extract_tool_response(response)
            elif response.stop_reason == "refusal":
                self.logger.warning(f"Scene {scene_data.get('scene_number')} refused")
                return None
            elif response.stop_reason == "max_tokens":
                self.logger.warning(f"Scene {scene_data.get('scene_number')} truncated")
                return self.extract_tool_response(response)
            else:  # end_turn
                return self.extract_tool_response(response)
                
        except RateLimitError as e:
            if retry_count < 3:
                retry_after = int(e.response.headers.get('retry-after', 2 ** retry_count))
                time.sleep(retry_after)
                return self.process_scene(scene_data, retry_count + 1)
            raise
            
        except APIError as e:
            if retry_count < 3:
                time.sleep(2 ** retry_count)  # Exponential backoff
                return self.process_scene(scene_data, retry_count + 1)
            raise
```

## Configuration Requirements

### API Request Configuration
```yaml
model: claude-opus-4-1-20250805
temperature: 0.3  # For consistency
max_tokens: 4096  # Safety cap only
tool_choice: required  # Force tool use
```

### Rate Limiting Configuration
```yaml
base_delay: 200  # milliseconds
max_retries: 3
exponential_base: 2  # For backoff calculation
```

### Error Handling Configuration
```yaml
retry_on:
  - rate_limit_error
  - api_error
  - overloaded_error
skip_on:
  - refusal
  - invalid_request_error
fatal_on:
  - authentication_error
```

## Performance Expectations

Given the typical scene file characteristics:
- **File size**: ~1.6KB per scene
- **API tokens**: ~400-500 input, ~200-300 output per shot
- **Processing time**: ~0.5-1 second per shot
- **Rate limits**: Well within Tier 1 limits (50 RPM, 30K ITPM)

## Summary

Focus on **reliability and simplicity** over performance optimization. The small file sizes and straightforward use case don't require complex features like batching or caching. Implement robust error handling, proper stop reason checking, and simple rate limiting for a production-ready solution.

### Priority Order for Implementation:
1. ✅ Tool-based API interaction
2. ✅ Stop reason handling
3. ✅ Basic error handling with retries
4. ✅ Simple rate limiting (200ms delay)
5. ✅ Request ID tracking for debugging
6. ⚠️ Response header monitoring (if time permits)
7. ❌ Skip: Batching, caching, streaming