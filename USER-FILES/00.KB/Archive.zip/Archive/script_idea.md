# scene-json->prompt


This document outlines the specification for **scene-json->prompt** (v0.1.0), a minimalist Python script that processes scene descriptions from JSON files and generates AI image prompts via the Anthropic API. The script recursively processes scene JSON arrays with system instructions to generate prompts suitable for Midjourney. 

This is what will happen. I leave it to the LLM that will write this code to decide which order these things will happen. I'm agnostic to that, but this is what should happen at some point during the process.

## Step 0 - Create Output Folder

For the run, the script should create a folder in `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/05.OUTPUT`
that is timestamped `YYMMDD_HHMMSS`.
## Step 1 - API Authentication

The script authenticates with the Anthropic API exclusively using 1Password CLI. No environment variables or fallback methods are supported.

- **1Password Item**: `API Anthropic`
- **Key Field**: `Api Key`
- **Method**: See authentication details in `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/00.KB/1password_cli_auth.md`

## Step 2 - Load Configuration

The script loads two configuration sources:

### Main Configuration
From `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/01.CONFIG/anthropic_config.json`: 

```json
{
  "model": "claude-opus-4-1-20250805",
  "max_tokens": 800,
  "temperature": 0.3,
  "stream": false,
  "tools": [
    {
      "name": "generate_prompts",
      "description": "Generate image prompts for scene shots",
      "input_schema": {
        "type": "object",
        "properties": {
          "scene_number": {
            "type": "integer",
            "description": "The scene number being processed"
          },
          "shots": {
            "type": "array",
            "description": "Array of shots with generated prompts",
            "items": {
              "type": "object",
              "properties": {
                "shot_number": {
                  "type": "integer",
                  "description": "The shot number within the scene"
                },
                "prompt": {
                  "type": "string",
                  "description": "Generated image prompt for Midjourney"
                }
              },
              "required": ["shot_number", "prompt"]
            }
          }
        },
        "required": ["scene_number", "shots"]
      }
    }
  ],
  "tool_choice": {"type": "tool", "name": "generate_prompts"},
  "fields_to_remove": ["oref", "camera_movement", "shot_timecode"]
}
```

### Profile Configuration (Optional)
From `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/03.PROFILES/profile.yaml`:

The profile can specify a suffix to append to all generated prompts. For example:
```yaml
prompt_suffix: " --ar 16:9 --v 6"
```

This suffix will be appended to every prompt value returned by the API before saving to the output file. Note: The suffix is shown in the final output example in Step 7.


## Step 3 - Prepare System Prompt

In the path `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/01.CONFIG/System Prompt/` there are numbered markdown files (e.g., `01_style.md`, `02_format.md`, etc.).

The script should:
1. Read all markdown files in numerical order based on their filename prefix
2. Merge them into one text in memory
3. Place one blank row between the content from each file
4. Cache this merged text for the entire run (don't reload for each file)
5. Add this merged text as the `system prompt` in the API payload 


## Step 4 - Process Input Files

In `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/04.INPUT` there will be a folder. The name of the folder shouldn't matter. The script should recursively process all JSON files within this folder. The scenes have roughly the same structure but the biggest difference is that some have one shot and some multiple shots. 


### Examples

```json
[
  {
    "scene_number": 1,
    "comment": "This is the establishing shot of the film setting the starting point of the story in mid 1700’s Stockholm, a deeply Lutheran and conservative country.",
    "period": "Late 1700s",
    "season": "Summer",
    "weather": "Clear-sky",
    "location": {
      "type": "Exterior",
      "location_name": "Outskirts of stockholm"
    },
    "diurnal": "Golden Hour",
    "light_source": "Coral pink sun",
    "shots": [
      {
        "shot_number": 1,
        "shot_size": "Crane Shot",
        "specific_area": "Rural settlement",
        "description": "Cozy settlement. Peasants walk along the paths toward a massive medieval church. In the distance, the sparse skyline of 18th-century Stockholm comes into view—Gamla Stan's clustered rooftops, the spires of church towers piercing the pale sky, and the silhouette of the Royal Palace rising over the city. Along the horizon, thin plumes of smoke curl upward from chimneys in the old town, dissipating into the gray northern air.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Move in"
        },
        "shot_timecode": {
          "in_time": "00:00:13,680",
          "out_time": "00:00:20,280"
        }
      }
    ]
  }
]

```



```json
[
  {
    "scene_number": 2,
    "comment": "To reflect the religious sentiment of the time, we show a Lutheran Christian service where a Jew converts to Christian for the privilege of living in Sweden.",
    "period": "Late 1700s",
    "location": {
      "type": "Interior",
      "location_name": "Medieval church"
    },
    "diurnal": "Day",
    "light_source": "Sunlight through stained church.",
    "shots": [
      {
        "shot_number": 2,
        "oref": "TRUE",
        "shot_size": "Long Shot",
        "specific_area": "Center aisle",
        "description": "Inside a MEDIEVAL_STONE_CHURCH, the view looks straight down the central aisle toward the west entrance. On the left side of the nave, male peasants sit quietly in the pews, heads bowed in prayer; on the right, female peasants mirror them in solemn devotion. Down the aisle advances a liturgical procession: at the front, a young crucifer carries the processional cross, followed by a SWEDISH_PRIEST in flowing vestments, flanked by catechists and deacons. Behind them, choir members proceed in hushed reverence, their footsteps echoing softly beneath the vaulted arches.",
        "camera_movement": {
          "speed": "Static",
          "type": "Locked"
        },
        "shot_timecode": {
          "in_time": "00:00:20,280",
          "out_time": "00:00:24,200"
        }
      },
      {
        "shot_number": 3,
        "shot_size": "Extreme Close Up",
        "specific_area": "Stands",
        "description": "Swedish teenage girl with closed eyes, clasping her hands against her face as she, bowing her head in a prayer.",
        "camera_movement": {
          "speed": "Steady",
          "type": "Handheld"
        },
        "shot_timecode": {
          "in_time": "00:00:24,200",
          "out_time": "00:00:26,840"
        }
      },
      {
        "shot_number": 4,
        "oref": "TRUE",
        "shot_size": "Low Medium Shot",
        "specific_area": "Podium",
        "description": "SWEDISH_PRIEST is preaching from the podium.",
        "camera_movement": {
          "speed": "Steady",
          "type": "Handheld"
        },
        "shot_timecode": {
          "in_time": "00:00:26,840",
          "out_time": "00:00:30,440"
        }
      },
      {
        "shot_number": 5,
        "shot_size": "Medium Shot",
        "specific_area": "Altar",
        "description": "A depiction in wood of Jesus Christ hanging on the cross.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:30,440",
          "out_time": "00:00:33,720"
        }
      },
      {
        "shot_number": 6,
        "oref": "TRUE",
        "shot_size": "Medium Shot",
        "specific_area": "Center aisle",
        "description": "The JEWISH_CONVERT stands in the center aisle.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:33,720",
          "out_time": "00:00:35,720"
        }
      },
      {
        "shot_number": 7,
        "oref": "TRUE",
        "shot_size": "Medium Wide Shot",
        "specific_area": "Baptismal font",
        "description": "SWEDISH_PRIEST is pouring water over the head of the JEWISH_CONVERT’s head.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:35,720",
          "out_time": "00:00:39,640"
        }
      },
      {
        "shot_number": 8,
        "oref": "TRUE",
        "shot_size": "Medium Close Up",
        "specific_area": "Center aisle",
        "description": "Water is running down the face of the JEWISH_CONVERT.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:39,640",
          "out_time": "00:00:43,440"
        }
      }
    ]
  }
]

```


```json
[
  {
    "scene_number": 16,
    "comment": "This scene is meant to show a slice of life of Jewish life in Sweden at the time.",
    "period": "Early 1800s",
    "location": {
      "type": "Interior",
      "location_name": "Small fabric store"
    },
    "diurnal": "Day",
    "light_source": "Dappled Sunlight from a skylight.",
    "shots": [
      {
        "shot_number": 44,
        "shot_size": "Medium Wide Shot",
        "specific_area": "Main room",
        "description": "Jewish merchant arranges bolts of colorful, oriental fabrics inside a large shop while a Swedish female customers  examine the fabrics.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:02:11,200",
          "out_time": "00:02:13,600"
        }
      }
    ]
  }
]

```


### Required Field Validation

Before processing any scene file, validate that it contains the required fields:

**Scene Level Requirements**:
- `scene_number` (required, integer)
- `shots` (required, array, non-empty)

**Shot Level Requirements** (for each shot in the shots array):
- `shot_number` (required, integer)
- `shot_size` (required, string)
- `description` (required, string, non-empty)

**Validation Behavior**:
- If a scene has an empty shots array:
  - Stop the script immediately
  - Log the error with the problematic file name
  - Exit with error status
- If multiple files have the same scene_number:
  - Stop the script immediately
  - Report the duplicate scene numbers and files
  - Exit with error status
- For other validation failures (missing fields):
  - Log the specific missing/invalid fields
  - Skip the file and continue with the next one
  - Record in `errors.log`: filename, timestamp, and reason for skipping

### Data Transformation

These JSON files should be sent as a user message but the script should remove configured fields before sending. The fields to remove are specified in the `fields_to_remove` array in the configuration file (e.g., `oref`, `camera_movement`, `shot_timecode`). 

## Step 5 - Send to API

The system prompt will tell the Anthropic API to read the scene broken down in the JSON array and return an AI image prompt.

### Rate Limiting

The script should implement rate limiting to respect Anthropic API limits:

- **Sequential Processing**: Process files one at a time (no parallel API calls)
- **API Limits**: Respect tier-based limits (Tier 1: 50 RPM, 30K ITPM, 8K OTPM for Claude Opus 4.1)
- **Retry Logic**: When receiving a 429 error:
  - Check the `retry-after` header for wait time
  - Implement exponential backoff with maximum 3 retries
  - Wait the specified time before retrying
- **Error Handling**: 
  - 401 Unauthorized: Stop immediately and report error
  - 429 Rate Limited: Wait and retry as specified above
  - 400 Bad Request: Stop the script and report error
  - 500 Server Error: Retry with exponential backoff
- **Delay Between Requests**: Add 200ms delay between API calls to avoid bursts


## Step 6 - API Response

The Anthropic API will process the scene data and return a JSON array with generated prompts for each shot.

### Original Input (from file)


```json
[
  {
    "scene_number": 16,
    "comment": "This scene is meant to show a slice of life of Jewish life in Sweden at the time.",
    "period": "Early 1800s",
    "location": {
      "type": "Interior",
      "location_name": "Small fabric store"
    },
    "diurnal": "Day",
    "light_source": "Dappled Sunlight from a skylight.",
    "shots": [
      {
        "shot_number": 44,
        "shot_size": "Medium Wide Shot",
        "specific_area": "Main room",
        "description": "Jewish merchant arranges bolts of colorful, oriental fabrics inside a large shop while a Swedish female customers  examine the fabrics.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:02:11,200",
          "out_time": "00:02:13,600"
        }
      }
    ]
  }
]

```




### Data Sent to API (with fields removed)

The script removes the specified fields and sends only this:

```json
[
  {
    "scene_number": 16,
    "comment": "This scene is meant to show a slice of life of Jewish life in Sweden at the time.",
    "period": "Early 1800s",
    "location": {
      "type": "Interior",
      "location_name": "Small fabric store"
    },
    "diurnal": "Day",
    "light_source": "Dappled Sunlight from a skylight.",
    "shots": [
      {
        "shot_number": 44,
        "shot_size": "Medium Wide Shot",
        "specific_area": "Main room",
        "description": "Jewish merchant arranges bolts of colorful, oriental fabrics inside a large shop while a Swedish female customers  examine the fabrics."
      }
    ]
  }
]

```

### API Response

The Anthropic API returns a JSON array with generated prompts:
```json
[
  {
    "scene_number": 16,
    "shots": [
      {
        "shot_number": 44,
        "prompt": "Early 1800s interior of a small fabric store in Sweden, medium wide shot of the main room. A Jewish merchant arranges bolts of colorful oriental fabrics on wooden shelves and tables while Swedish female customers examine the textiles. Dappled sunlight streams down from a skylight above, creating warm patches of light on the fabrics and wooden floors. The scene captures authentic period details - the merchant in traditional early 19th century clothing, customers in Swedish dress of the era, and rich, patterned fabrics in deep blues, reds, and golds typical of oriental textiles. The atmosphere is intimate and commercial, showing a slice of Jewish merchant life in Sweden during this historical period."
      }
    ]
  }
]
```


## Step 7 - Merge and Save Output

In the folder that the script creates in `/Users/ruben/08_-_DEVELOPMENT/ISOF__TEXT_WORKFLOW/03.json_short->prompt/USER-FILES/05.OUTPUT` the script should save one JSON file per input scene file. Each output file should contain the original JSON data (with all fields intact) merged with the `prompt` field that was returned from the API, placing it at the end of each shot object.

### Original Data (as read from input file) 


```json
[
  {
    "scene_number": 16,
    "comment": "This scene is meant to show a slice of life of Jewish life in Sweden at the time.",
    "period": "Early 1800s",
    "location": {
      "type": "Interior",
      "location_name": "Small fabric store"
    },
    "diurnal": "Day",
    "light_source": "Dappled Sunlight from a skylight.",
    "shots": [
      {
        "shot_number": 44,
        "shot_size": "Medium Wide Shot",
        "specific_area": "Main room",
        "description": "Jewish merchant arranges bolts of colorful, oriental fabrics inside a large shop while a Swedish female customers  examine the fabrics.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:02:11,200",
          "out_time": "00:02:13,600"
        }
      }
    ]
  }
]

```


### Final Output (saved to OUTPUT folder)

After receiving the prompts from the API, the script merges them with the original data and saves the complete JSON:



```json
[
  {
    "scene_number": 16,
    "comment": "This scene is meant to show a slice of life of Jewish life in Sweden at the time.",
    "period": "Early 1800s",
    "location": {
      "type": "Interior",
      "location_name": "Small fabric store"
    },
    "diurnal": "Day",
    "light_source": "Dappled Sunlight from a skylight.",
    "shots": [
      {
        "shot_number": 44,
        "shot_size": "Medium Wide Shot",
        "specific_area": "Main room",
        "description": "Jewish merchant arranges bolts of colorful, oriental fabrics inside a large shop while a Swedish female customers  examine the fabrics.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:02:11,200",
          "out_time": "00:02:13,600"
        },
        "prompt": "Early 1800s interior of a small fabric store in Sweden, medium wide shot of the main room. A Jewish merchant arranges bolts of colorful oriental fabrics on wooden shelves and tables while Swedish female customers examine the textiles. Dappled sunlight streams down from a skylight above, creating warm patches of light on the fabrics and wooden floors. The scene captures authentic period details - the merchant in traditional early 19th century clothing, customers in Swedish dress of the era, and rich, patterned fabrics in deep blues, reds, and golds typical of oriental textiles. The atmosphere is intimate and commercial, showing a slice of Jewish merchant life in Sweden during this historical period. --ar 16:9 --v 6"
        }
      }
    ]
  }
]

```


## Note on multiple shots

The example above has only one shot within the same scene but a scene can have multiple shots as shown above. These are the shots from the same scene so they should have continuity. 


So the script reads: 



```json
[
  {
    "scene_number": 2,
    "comment": "To reflect the religious sentiment of the time, we show a Lutheran Christian service where a Jew converts to Christian for the privilege of living in Sweden.",
    "period": "Late 1700s",
    "location": {
      "type": "Interior",
      "location_name": "Medieval church"
    },
    "diurnal": "Day",
    "light_source": "Sunlight through stained church.",
    "shots": [
      {
        "shot_number": 2,
        "oref": "TRUE",
        "shot_size": "Long Shot",
        "specific_area": "Center aisle",
        "description": "Inside a MEDIEVAL_STONE_CHURCH, the view looks straight down the central aisle toward the west entrance. On the left side of the nave, male peasants sit quietly in the pews, heads bowed in prayer; on the right, female peasants mirror them in solemn devotion. Down the aisle advances a liturgical procession: at the front, a young crucifer carries the processional cross, followed by a SWEDISH_PRIEST in flowing vestments, flanked by catechists and deacons. Behind them, choir members proceed in hushed reverence, their footsteps echoing softly beneath the vaulted arches.",
        "camera_movement": {
          "speed": "Static",
          "type": "Locked"
        },
        "shot_timecode": {
          "in_time": "00:00:20,280",
          "out_time": "00:00:24,200"
        }
      },
      {
        "shot_number": 3,
        "shot_size": "Extreme Close Up",
        "specific_area": "Stands",
        "description": "Swedish teenage girl with closed eyes, clasping her hands against her face as she, bowing her head in a prayer.",
        "camera_movement": {
          "speed": "Steady",
          "type": "Handheld"
        },
        "shot_timecode": {
          "in_time": "00:00:24,200",
          "out_time": "00:00:26,840"
        }
      },
      {
        "shot_number": 4,
        "oref": "TRUE",
        "shot_size": "Low Medium Shot",
        "specific_area": "Podium",
        "description": "SWEDISH_PRIEST is preaching from the podium.",
        "camera_movement": {
          "speed": "Steady",
          "type": "Handheld"
        },
        "shot_timecode": {
          "in_time": "00:00:26,840",
          "out_time": "00:00:30,440"
        }
      },
      {
        "shot_number": 5,
        "shot_size": "Medium Shot",
        "specific_area": "Altar",
        "description": "A depiction in wood of Jesus Christ hanging on the cross.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:30,440",
          "out_time": "00:00:33,720"
        }
      },
      {
        "shot_number": 6,
        "oref": "TRUE",
        "shot_size": "Medium Shot",
        "specific_area": "Center aisle",
        "description": "The JEWISH_CONVERT stands in the center aisle.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:33,720",
          "out_time": "00:00:35,720"
        }
      },
      {
        "shot_number": 7,
        "oref": "TRUE",
        "shot_size": "Medium Wide Shot",
        "specific_area": "Baptismal font",
        "description": "SWEDISH_PRIEST is pouring water over the head of the JEWISH_CONVERT’s head.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:35,720",
          "out_time": "00:00:39,640"
        }
      },
      {
        "shot_number": 8,
        "oref": "TRUE",
        "shot_size": "Medium Close Up",
        "specific_area": "Center aisle",
        "description": "Water is running down the face of the JEWISH_CONVERT.",
        "camera_movement": {
          "speed": "Slow & smooth",
          "type": "Dolly-in"
        },
        "shot_timecode": {
          "in_time": "00:00:39,640",
          "out_time": "00:00:43,440"
        }
      }
    ]
  }
]

```

The script sends the JSON array with only the permitted values: 

```json
[
  {
    "scene_number": 2,
    "comment": "To reflect the religious sentiment of the time, we show a Lutheran Christian service where a Jew converts to Christian for the privilege of living in Sweden.",
    "period": "Late 1700s",
    "location": {
      "type": "Interior",
      "location_name": "Medieval church"
    },
    "diurnal": "Day",
    "light_source": "Sunlight through stained church.",
    "shots": [
      {
        "shot_number": 2,
        "shot_size": "Long Shot",
        "specific_area": "Center aisle",
        "description": "Inside a MEDIEVAL_STONE_CHURCH, the view looks straight down the central aisle toward the west entrance. On the left side of the nave, male peasants sit quietly in the pews, heads bowed in prayer; on the right, female peasants mirror them in solemn devotion. Down the aisle advances a liturgical procession: at the front, a young crucifer carries the processional cross, followed by a SWEDISH_PRIEST in flowing vestments, flanked by catechists and deacons. Behind them, choir members proceed in hushed reverence, their footsteps echoing softly beneath the vaulted arches."
      },
      {
        "shot_number": 3,
        "shot_size": "Extreme Close Up",
        "specific_area": "Stands",
        "description": "Swedish teenage girl with closed eyes, clasping her hands against her face as she, bowing her head in a prayer."
      },
      {
        "shot_number": 4,
        "shot_size": "Low Medium Shot",
        "specific_area": "Podium",
        "description": "SWEDISH_PRIEST is preaching from the podium."
      },
      {
        "shot_number": 5,
        "shot_size": "Medium Shot",
        "specific_area": "Altar",
        "description": "A depiction in wood of Jesus Christ hanging on the cross."
      },
      {
        "shot_number": 6,
        "shot_size": "Medium Shot",
        "specific_area": "Center aisle",
        "description": "The JEWISH_CONVERT stands in the center aisle."
      },
      {
        "shot_number": 7,
        "shot_size": "Medium Wide Shot",
        "specific_area": "Baptismal font",
        "description": "SWEDISH_PRIEST is pouring water over the head of the JEWISH_CONVERT's head."
      },
      {
        "shot_number": 8,
        "shot_size": "Medium Close Up",
        "specific_area": "Center aisle",
        "description": "Water is running down the face of the JEWISH_CONVERT."
      }
    ]
  }
]
```

#### API Response (Incorrect - Missing Prompts)

Note: This example incorrectly shows description fields. The API should return prompts instead:

```json
[
  {
    "scene_number": 2,
    "shots": [
      {
        "shot_number": 2,
        "description": "Inside a MEDIEVAL_STONE_CHURCH, the view looks straight down the central aisle toward the west entrance. On the left side of the nave, male peasants sit quietly in the pews, heads bowed in prayer; on the right, female peasants mirror them in solemn devotion. Down the aisle advances a liturgical procession: at the front, a young crucifer carries the processional cross, followed by a SWEDISH_PRIEST in flowing vestments, flanked by catechists and deacons. Behind them, choir members proceed in hushed reverence, their footsteps echoing softly beneath the vaulted arches."
      },
      {
        "shot_number": 3,
        "description": "Swedish teenage girl with closed eyes, clasping her hands against her face as she, bowing her head in a prayer."
      },
      {
        "shot_number": 4,
        "description": "SWEDISH_PRIEST is preaching from the podium."
      },
      {
        "shot_number": 5,
        "description": "A depiction in wood of Jesus Christ hanging on the cross."
      },
      {
        "shot_number": 6,
        "description": "The JEWISH_CONVERT stands in the center aisle."
      },
      {
        "shot_number": 7,
        "description": "SWEDISH_PRIEST is pouring water over the head of the JEWISH_CONVERT's head."
      },
      {
        "shot_number": 8,
        "description": "Water is running down the face of the JEWISH_CONVERT."
      }
    ]
  }
]
```

#### Correct API Response

**CRITICAL**: The Anthropic API needs to consider the scene descriptors such as `comment`, `period`, `location` and `location_name`, `diurnal`, `Day`, `light_source` and think deeply about how these should influence all the `shots` as every shot is a child of the scene and thereby subject to its descriptors.

The Anthropic API should return:

```json
[
  {
    "scene_number": 2,
    "shots": [
      {
        "shot_number": 2,
        "prompt": "Late 1700s medieval stone church interior, long shot down central aisle toward west entrance. Male peasants in left pews, female peasants in right pews, heads bowed in prayer. Liturgical procession advancing: young crucifer with processional cross, Swedish priest in flowing vestments, catechists, deacons, and choir members. Sunlight through stained glass windows, vaulted stone arches."
      },
      {
        "shot_number": 3,
        "prompt": "Late 1700s extreme close-up of Swedish teenage girl in church pew. Eyes closed, hands clasped against face, head bowed in prayer. Period-appropriate dress. Soft sunlight through stained glass illuminating her face."
      },
      {
        "shot_number": 4,
        "prompt": "Late 1700s low medium shot of Swedish priest preaching from wooden church podium. Medieval stone church interior, flowing religious vestments, sunlight through stained glass windows creating atmospheric lighting."
      },
      {
        "shot_number": 5,
        "prompt": "Late 1700s medium shot of wooden crucifix depicting Jesus Christ on the cross. Medieval church altar, carved wood craftsmanship typical of the period. Sunlight through stained glass creating reverent atmosphere."
      },
      {
        "shot_number": 6,
        "prompt": "Late 1700s medium shot of Jewish convert standing solemnly in center aisle of medieval stone church. Period-appropriate clothing, sunlight through stained glass windows, stone pillars and vaulted architecture visible."
      },
      {
        "shot_number": 7,
        "prompt": "Late 1700s medium wide shot at baptismal font. Swedish priest in vestments pouring water over Jewish convert's head during baptism ceremony. Medieval stone church interior, sunlight through stained glass, stone baptismal font."
      },
      {
        "shot_number": 8,
        "prompt": "Late 1700s medium close-up of Jewish convert's face during baptism. Water running down face, eyes closed, expression of solemnity. Medieval church interior with soft sunlight through stained glass creating dramatic lighting on wet skin."
      }
    ]
  }
]
```


### Final Output

These prompts are then merged with the original data and saved to OUTPUT just like the single-shot scenes.


## Step 8 - Iterate Through All Files

When the JSON is saved the script then loads the next JSON file in the input folder (recursively) and repeats the process with all the JSON files until there are no more and the script exits.

### Dry-Run Mode

The script should support a `--dry-run` mode that:

- Validates all JSON files without calling the API
- Shows what would be sent to the API for each file
- Reports validation results for all files
- Displays the system prompt that would be used
- Shows the fields that would be removed from each scene
- Provides a summary of files that would be processed vs skipped

### Progress Tracking

The script should provide clear progress indicators:

- **File Progress**: Display current file being processed (e.g., "Processing file 3 of 12: scene_16.json")
- **Completion Percentage**: Show overall progress (e.g., "25% complete")
- **Time Tracking**: 
  - Log timestamp for each file start/end
  - Calculate and display average processing time per file
  - Show estimated time remaining based on average
- **Logging**:
  - Create a `processing_log.txt` in the output folder
  - Log each file processed with timestamp and status
  - Record any errors or skipped files
- **Console Output**: Clear, formatted output showing:
  ```
  [2024-12-20 14:32:15] Processing: scene_16.json (3/12)
  [■■■□□□□□□□] 25% Complete | ETA: 2 minutes
  ```

### Summary Report

At the end of processing, generate a summary report (`summary_report.md`) in the output folder containing:

- Total files processed successfully
- Total files failed/skipped
- Total API calls made
- Average processing time per scene
- List of any errors or warnings
- Timestamp of processing run
- Configuration used (model, temperature, etc.)

## Important Notes

- **File Management**: The script must never move, delete, or rename input files. All input files remain in `04.INPUT/` after processing.
- **Error Handling**: Stop immediately for critical errors (empty shots, duplicate scenes, 401/400 errors). Continue processing for individual file validation failures.
- **Configuration**: Only hardcoded configuration, JSON config file, and YAML profile are used. No command-line arguments or environment variables except for 1Password authentication.
- **Processing**: One scene per API call, sequential processing only (no parallel API calls).
- **MVP Focus**: This is version 0.1.0 - keep implementation minimal and focused on core functionality.